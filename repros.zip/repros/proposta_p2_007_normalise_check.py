import math
from PIL import Image
def new(image):
    if image.mode.startswith("I;16"):
        g = image.convert("I")
        try: return g.point(lambda v: v / 257).convert("L")
        finally: g.close()
    if image.mode in {"I", "F"}:
        low, high = (float(x) for x in image.getextrema())
        if not (math.isfinite(low) and math.isfinite(high)): return Image.new("L", image.size, 0)
        if image.mode == "F" and 0.0 <= low and high <= 1.0: lo, hi = 0.0, 1.0
        elif 0 <= low and high <= 255: lo, hi = 0.0, 255.0
        elif 0 <= low and high <= 65535: lo, hi = 0.0, 65535.0
        else: lo, hi = low, high
        if hi == lo: return Image.new("L", image.size, 0)
        s = 255.0 / (hi - lo)
        return image.point(lambda v: (v - lo) * s).convert("L")
    return image
def px(im): return list(im.get_flattened_data())
a = Image.new("I", (2, 1)); a.putpixel((0, 0), 50); a.putpixel((1, 0), 200); print("I 50,200 ->", px(new(a)))
b = Image.new("I", (2, 1)); b.putpixel((0, 0), 100); b.putpixel((1, 0), 250); print("I 100,250 ->", px(new(b)))
c = Image.new("I", (2, 1)); c.putpixel((0, 0), 0); c.putpixel((1, 0), 65535); print("I 0,65535 ->", px(new(c)))
d = Image.new("I", (2, 1)); d.putpixel((0, 0), -1000); d.putpixel((1, 0), 70000); print("I -1000,70000 ->", px(new(d)))
f = Image.new("F", (2, 1)); f.putpixel((0, 0), 0.0); f.putpixel((1, 0), 1.0); print("F 0,1 ->", px(new(f)))
g = Image.new("F", (2, 1), 0.5); print("F const 0.5 ->", px(new(g)))
