"""recommend_dpi_from_images decodifica a imagem inteira so para ler o tamanho; tipos de excecao de arquivos corrompidos."""
import _common, tempfile, time, resource
from pathlib import Path
from PIL import Image, ImageOps
from document_tools.image_resolution import recommend_dpi_from_images
tmp = Path(tempfile.mkdtemp())
p = tmp / "foto.jpg"; Image.effect_noise((6000, 4000), 50).convert("RGB").save(p, quality=90)
paths = [p] * 8
t = time.time(); r = recommend_dpi_from_images(paths); dt = time.time() - t
print(f"recommend_dpi (8 JPEG 24MP): {dt:.2f}s resultado={r}")
t = time.time()
for q in paths:
    with Image.open(q) as im: _ = im.size
print(f"apenas Image.open().size (8x): {time.time()-t:.3f}s")
# corrupcao: tipos de excecao
good = tmp / "g.png"; Image.new("RGB", (200, 100), "red").save(good)
data = bytearray(good.read_bytes())
cases = {}
d = bytearray(data); i = d.index(b"IDAT"); d[i - 4:i] = (9999999).to_bytes(4, "big"); cases["IDAT com tamanho absurdo"] = d
d = bytearray(data); i = d.index(b"IHDR"); d[i + 4:i + 12] = b"\x00" * 8; cases["IHDR zerado"] = d
d = bytearray(data); j = d.index(b"IEND"); d[j - 4:j] = b"\x00\x00\x00\x00"; cases["IDAT zerado/CRC"] = d
d = bytearray(data); i = d.index(b"IDAT"); d[i + 4:i + 20] = b"\xff" * 16; cases["IDAT lixo"] = d
for name, content in cases.items():
    f = tmp / "c.png"; f.write_bytes(content)
    try:
        r = recommend_dpi_from_images([good, f]); print(f"{name:26s} -> ok ({r})")
    except BaseException as e:
        print(f"{name:26s} -> ESCAPOU {type(e).__module__}.{type(e).__name__}: {str(e)[:60]}")
