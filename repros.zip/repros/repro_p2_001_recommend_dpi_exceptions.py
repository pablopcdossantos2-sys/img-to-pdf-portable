"""recommend_dpi_from_images deixa escapar DecompressionBombError/SyntaxError (nao sao OSError/ValueError/EOFError)."""
import _common, struct, sys, tempfile, zlib, warnings
from pathlib import Path
from PIL import Image
from document_tools.image_resolution import recommend_dpi_from_images
print("Pillow", Image.__version__, "MAX_IMAGE_PIXELS", Image.MAX_IMAGE_PIXELS)
tmp = Path(tempfile.mkdtemp())

# 1) PNG com CRC invalido em IDAT -> SyntaxError
good = tmp / "good.png"; Image.new("RGB", (200, 100), "red").save(good)
data = bytearray(good.read_bytes())
i = data.index(b"IDAT"); data[i + 8] ^= 0xFF  # corrompe payload do IDAT
bad = tmp / "badcrc.png"; bad.write_bytes(data)
# 2) bomba de descompressao (> 2 * MAX_IMAGE_PIXELS)
bomb = tmp / "bomb.png"; Image.new("L", (20000, 10000), 0).save(bomb)

for name, p in [("crc_invalido", bad), ("bomba", bomb)]:
    try:
        r = recommend_dpi_from_images([good, p])
        print(name, "-> retornou", r)
    except BaseException as e:
        print(name, "-> EXCECAO ESCAPOU:", type(e).__mro__[0].__module__ + "." + type(e).__name__, "|", str(e)[:90])
