"""thumbnail em modo P usa NEAREST; convert_image descarta quadros de GIF/TIFF/WEBP animados sem aviso."""
import _common, tempfile
from pathlib import Path
from PIL import Image, ImageDraw
from document_tools.pdf_ops import convert_image
tmp = Path(tempfile.mkdtemp())

# (a) PNG paletizado com diagonais finas, reduzido 4x
base = Image.new("RGB", (800, 800), "white"); d = ImageDraw.Draw(base)
for i in range(0, 800, 16): d.line((0, i, 800, 800 - i), fill="black", width=1)
pal = tmp / "pal.png"; base.convert("P", palette=Image.Palette.ADAPTIVE, colors=8).save(pal)
rgb = tmp / "rgb.png"; base.save(rgb)
convert_image(pal, tmp / "pal_out.png", "PNG", max_width=200, max_height=200)
convert_image(rgb, tmp / "rgb_out.png", "PNG", max_width=200, max_height=200)
for n in ("pal_out", "rgb_out"):
    im = Image.open(tmp / f"{n}.png").convert("RGB")
    print(f"{n}: cores distintas apos reduzir 4x = {len(set(im.get_flattened_data()))}")

# (b) quadros
frames = [Image.new("RGB", (64, 64), c) for c in ("red", "green", "blue")]
gif = tmp / "anim.gif"; frames[0].save(gif, save_all=True, append_images=frames[1:], duration=100, loop=0)
tif = tmp / "multi.tif"; frames[0].save(tif, save_all=True, append_images=frames[1:])
for s in (gif, tif):
    with Image.open(s) as im: n = im.n_frames
    out = convert_image(s, tmp / f"{s.stem}_out.png", "PNG")
    with Image.open(out) as o: print(f"{s.name}: {n} quadros na origem -> saida PNG com n_frames={getattr(o,'n_frames',1)} (sem aviso ao usuario)")
