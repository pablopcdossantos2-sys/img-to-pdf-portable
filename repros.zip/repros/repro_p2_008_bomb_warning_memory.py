"""Faixa 1x-2x de MAX_IMAGE_PIXELS: so aviso (DecompressionBombWarning), processa e consome muita memoria."""
import _common, tempfile, resource, warnings, sys, time
from pathlib import Path
from PIL import Image
from document_tools.pdf_ops import images_to_pdf, convert_image
tmp = Path(tempfile.mkdtemp())
src = tmp / "grande.png"
Image.new("RGB", (10000, 10000), (200, 30, 30)).save(src)   # 100 MP (> 89,5 MP, < 179 MP)
print("arquivo PNG:", src.stat().st_size, "bytes; pixels:", 10000 * 10000)
print("pico RSS antes (MB):", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    t = time.time(); images_to_pdf([src], tmp / "o.pdf", dpi=150, margin_mm=10)
    print("images_to_pdf ok em %.1fs; avisos capturados: %s" % (time.time() - t, [x.category.__name__ for x in w]))
print("pico RSS apos images_to_pdf (MB):", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024)
