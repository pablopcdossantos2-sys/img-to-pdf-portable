"""_normalise_high_bit_depth: modo I estica contraste; I;16 de 12 bits fica quase preto; F com inf."""
import _common
from PIL import Image
from document_tools.pdf_ops import _normalise_high_bit_depth as n

# (a) modo 'I' com valores 50..200 (tons que ja estao em 0..255)
im = Image.new("I", (2, 1)); im.putpixel((0, 0), 50); im.putpixel((1, 0), 200)
out = n(im); print("I  50,200  ->", list(out.get_flattened_data()), "(esperado preservar 50,200 segundo o comentario do codigo)")
# (b) I;16 com dados de 12 bits (0..4095)
im16 = Image.new("I;16", (2, 1)); im16.putpixel((0, 0), 0); im16.putpixel((1, 0), 4095)
out = n(im16); print("I;16 0,4095 ->", list(out.get_flattened_data()), "(branco esperado = 255)")
# (c) mesma imagem 'I' em duas versoes: pagina clara e pagina escura recebem tons diferentes
a = Image.new("I", (2, 1)); a.putpixel((0, 0), 100); a.putpixel((1, 0), 120)
b = Image.new("I", (2, 1)); b.putpixel((0, 0), 100); b.putpixel((1, 0), 250)
print("I  100,120 ->", list(n(a).get_flattened_data()), "| I  100,250 ->", list(n(b).get_flattened_data()), "(pixel 100 deveria ser igual nas duas)")
# (d) F com inf
f = Image.new("F", (2, 1)); f.putpixel((0, 0), 0.0); f.putpixel((1, 0), float("inf"))
try:
    print("F 0,inf ->", list(n(f).get_flattened_data()))
except Exception as e:
    print("F 0,inf -> EXCECAO", type(e).__name__, e)
