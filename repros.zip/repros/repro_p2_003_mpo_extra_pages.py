"""JPEG MPO (fotos de celular com mapa de ganho/profundidade) vira varias paginas com all_frames=True (padrao)."""
import _common, tempfile
from pathlib import Path
from PIL import Image
from pypdf import PdfReader
from document_tools.pdf_ops import images_to_pdf
tmp = Path(tempfile.mkdtemp())
main = Image.new("RGB", (1200, 900), (30, 120, 200))
gain = Image.new("L", (300, 225), 128)               # simula gain map/preview secundario
mpo = tmp / "foto_celular.jpg"
main.save(mpo, format="MPO", save_all=True, append_images=[gain.convert("RGB")])
with Image.open(mpo) as im:
    print("formato:", im.format, "n_frames:", getattr(im, "n_frames", 1), "sufixo:", mpo.suffix)
out = images_to_pdf([mpo], tmp / "saida.pdf")
print("paginas no PDF (esperado 1):", len(PdfReader(out).pages))
out2 = images_to_pdf([mpo], tmp / "saida2.pdf", all_frames=False)
print("paginas com all_frames=False:", len(PdfReader(out2).pages))
