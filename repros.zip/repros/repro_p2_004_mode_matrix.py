"""Matriz modo x formato para images_to_pdf e convert_image (falhas e mensagens)."""
import _common, tempfile
from pathlib import Path
from PIL import Image
from document_tools.pdf_ops import images_to_pdf, convert_image
from document_tools.errors import friendly_error_message
tmp = Path(tempfile.mkdtemp())

def make(mode):
    if mode == "P":
        im = Image.new("RGB", (40, 30), "red").convert("P", palette=Image.Palette.ADAPTIVE)
        im.info["transparency"] = 0
        return im
    if mode == "PA":
        return Image.new("RGBA", (40, 30), (255, 0, 0, 128)).convert("PA")
    if mode in ("I", "I;16", "F"):
        return Image.new(mode, (40, 30), 1000 if mode != "F" else 0.5)
    if mode == "1":
        return Image.new("1", (40, 30), 1)
    return Image.new(mode, (40, 30))

modes = ["1", "L", "LA", "P", "PA", "RGB", "RGBA", "CMYK", "YCbCr", "LAB", "HSV", "I", "I;16", "F"]
fmts = [("JPEG", ".jpg"), ("PNG", ".png"), ("WEBP", ".webp"), ("BMP", ".bmp"), ("TIFF", ".tif")]
for mode in modes:
    try:
        src_im = make(mode)
        src = tmp / f"src_{mode.replace(';','_')}.tif"
        src_im.save(src, format="TIFF")
    except Exception as e:
        print(f"[{mode}] nao foi possivel criar fonte TIFF: {type(e).__name__}: {e}")
        continue
    row = []
    try:
        images_to_pdf([src], tmp / f"o_{mode.replace(';','_')}.pdf"); row.append("PDF:ok")
    except Exception as e:
        row.append(f"PDF:FALHA({type(e).__name__}: {e} | msg_usuario={friendly_error_message(e)[:40]!r})")
    for fmt, ext in fmts:
        try:
            convert_image(src, tmp / f"c_{mode.replace(';','_')}{ext}", fmt); row.append(f"{fmt}:ok")
        except Exception as e:
            row.append(f"{fmt}:FALHA({type(e).__name__}: {e})")
    print(f"[{mode}] " + " ; ".join(row))
