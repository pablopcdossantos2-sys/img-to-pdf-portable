"""Quais mensagens de erro da Parte 2 existem em TRANSLATIONS (en/es) de gui.py? Analise estatica via ast (sem importar PySide6)."""
import ast, sys
from pathlib import Path
import os
R = Path(os.environ.get("PDFHUB_REPO", "..")) / "document_tools"
gui = ast.parse((R / "gui.py").read_text(encoding="utf-8"))

# chaves de TRANSLATIONS["en"/"es"] (dict literal e .update({...}))
keys = {"en": set(), "es": set()}
def dict_keys(d):
    return {k.value for k in d.keys if isinstance(k, ast.Constant) and isinstance(k.value, str)}
for node in ast.walk(gui):
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "TRANSLATIONS" for t in node.targets) and isinstance(node.value, ast.Dict):
        for k, v in zip(node.value.keys, node.value.values):
            if isinstance(k, ast.Constant) and k.value in keys and isinstance(v, ast.Dict):
                keys[k.value] |= dict_keys(v)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "update":
        t = node.func.value
        if isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name) and t.value.id == "TRANSLATIONS" and node.args and isinstance(node.args[0], ast.Dict):
            lang = t.slice.value if isinstance(t.slice, ast.Constant) else None
            if lang in keys: keys[lang] |= dict_keys(node.args[0])
print("chaves en/es:", len(keys["en"]), len(keys["es"]))

def raised_messages(path, funcs=None):
    tree = ast.parse(path.read_text(encoding="utf-8")); out = []
    for fn in [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]:
        if funcs and fn.name not in funcs: continue
        for n in ast.walk(fn):
            if isinstance(n, ast.Raise) and isinstance(n.exc, ast.Call) and n.exc.args:
                a = n.exc.args[0]
                if isinstance(a, ast.Constant) and isinstance(a.value, str): out.append((fn.name, n.lineno, a.value, False))
                elif isinstance(a, ast.JoinedStr): out.append((fn.name, n.lineno, ast.unparse(a), True))
    return out
targets = [
 (R/"pdf_ops.py", {"_resize_to_a4","images_to_pdf","convert_image","_normalise_high_bit_depth","_flatten_to_rgb","_format_image_for_output","_validate_file_mode"}),
 (R/"image_resolution.py", None), (R/"pdf_rendering.py", None)]
missing = []; dyn = []
for p, f in targets:
    for fn, ln, msg, isf in raised_messages(p, f):
        if isf: dyn.append((p.name, ln, fn, msg)); continue
        for lang in ("en", "es"):
            if msg not in keys[lang]: missing.append((p.name, ln, fn, lang, msg))
print("\nMENSAGENS ESTATICAS SEM TRADUCAO:")
seen = set()
for m in missing:
    k = (m[0], m[1])
    if k in seen: continue
    seen.add(k); print(f"  {m[0]}:{m[1]} ({m[2]}) falta em {[x[3] for x in missing if (x[0],x[1])==k]} -> {m[4]}")
print("\nMENSAGENS DINAMICAS (f-string; nunca casam com a tabela exata):")
for d in dyn: print("  %s:%d (%s) %s" % d)
# mensagens de errors.py
errs = ast.parse((R/"errors.py").read_text(encoding="utf-8"))
print("\nerrors.py sem traducao:", [n.value[:40] for n in ast.walk(errs) if isinstance(n, ast.Constant) and isinstance(n.value, str) and len(n.value) > 40 and (n.value not in keys["en"] or n.value not in keys["es"])])
