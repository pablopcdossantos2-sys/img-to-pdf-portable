"""Limites de encoders (WEBP 16383, JPEG 65500) -> mensagem ao usuario."""
import _common, tempfile
from pathlib import Path
from PIL import Image
from document_tools.pdf_ops import convert_image
from document_tools.errors import friendly_error_message
tmp = Path(tempfile.mkdtemp())
src = tmp / "larga.png"; Image.new("RGB", (17000, 20), "blue").save(src)
for fmt, ext in (("WEBP", ".webp"), ("JPEG", ".jpg")):
    try:
        convert_image(src, tmp / f"o{ext}", fmt); print(fmt, "ok")
    except Exception as e:
        print(fmt, "->", type(e).__module__ + "." + type(e).__name__, "|", e, "| usuario:", friendly_error_message(e))
big = tmp / "enorme.png"; Image.new("L", (70000, 10), 5).save(big)
try:
    convert_image(big, tmp / "o2.jpg", "JPEG")
except Exception as e:
    print("JPEG 70000px ->", type(e).__name__, "|", e, "| usuario:", friendly_error_message(e))
