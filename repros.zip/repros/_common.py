"""Helper dos repros: aponta o sys.path para a raiz do repositorio.
Uso: PDFHUB_REPO=/caminho/para/img-to-pdf-portable-main python repro_xxx.py  (padrao: ../ do diretorio atual)."""
import os, sys
sys.path.insert(0, os.path.abspath(os.environ.get("PDFHUB_REPO", "..")))
