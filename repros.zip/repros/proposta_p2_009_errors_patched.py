"""User-friendly errors for background document processing."""
from __future__ import annotations

import errno

_THIRD_PARTY_ROOTS = {"PIL", "pypdf", "reportlab", "PySide6", "cryptography"}


def _origin_root(error: BaseException) -> str:
    """Top-level package of the innermost Python frame that raised ``error``."""
    traceback = error.__traceback__
    module = ""
    while traceback is not None:
        module = str(traceback.tb_frame.f_globals.get("__name__", ""))
        traceback = traceback.tb_next
    return module.split(".", 1)[0]


def friendly_error_message(error: Exception) -> str:
    """Return a localized-safe message without exposing arbitrary library details."""
    if isinstance(error, PermissionError):
        return "Não foi possível acessar ou salvar o arquivo. Confira as permissões e feche o documento em outros programas."
    if isinstance(error, FileNotFoundError):
        return "O arquivo ou a pasta não foi encontrado. Confira o caminho e tente novamente."
    if isinstance(error, FileExistsError):
        return "Um arquivo de destino já existe. Escolha outra pasta ou nome."
    if isinstance(error, (IsADirectoryError, NotADirectoryError)):
        return "O caminho escolhido não serve para esta operação (arquivo no lugar de pasta, ou o contrário)."
    if isinstance(error, MemoryError):
        return "Memória insuficiente para concluir a operação. Feche outros programas ou use uma resolução/imagem menor."
    if isinstance(error, OSError) and error.errno == errno.ENOSPC:
        return "Não há espaço livre suficiente no disco de destino."
    error_type = error.__class__.__name__
    module_name = error.__class__.__module__
    origin = _origin_root(error)
    if error_type in {"UnidentifiedImageError", "DecompressionBombError"}:
        return "A imagem é inválida, muito grande para processar com segurança ou usa um formato não suportado."
    if error_type in {"WrongPasswordError", "FileNotDecryptedError"}:
        return "Não foi possível interpretar o PDF. Ele pode estar danificado ou protegido por senha."
    if error_type == "DependencyError":
        return "Falta um componente de criptografia nesta instalação. Reinstale o aplicativo."
    if module_name.startswith("pypdf") or (origin == "pypdf" and not isinstance(error, ValueError)):
        return "O PDF contém uma estrutura não suportada ou está danificado. Tente salvar uma nova cópia do PDF antes de processar."
    if module_name.startswith("PIL") or origin == "PIL":
        return "A imagem não pôde ser processada. Verifique se o arquivo está íntegro e usa um formato compatível."
    if isinstance(error, UnicodeError):
        return "O texto ou o nome de arquivo contém caracteres que esta operação não consegue usar."
    if isinstance(error, ValueError) and origin not in _THIRD_PARTY_ROOTS:
        return str(error)
    if error_type == "RuntimeError" and str(error).startswith("Não foi possível concluir"):
        return str(error)
    return "Não foi possível concluir a operação. Os detalhes internos foram ocultados."
