"""Propriedades do PDF gerado: re-encode JPEG q95 de PNG/JPEG, cinza->RGB, ICC descartado, tamanho de pagina."""
import _common, tempfile, io
from pathlib import Path
from PIL import Image, ImageCms, ImageDraw
from pypdf import PdfReader
from document_tools.pdf_ops import images_to_pdf
tmp = Path(tempfile.mkdtemp())

# PNG de captura de tela: texto/linhas nitidas, 1600x1000 (cabe em A4 paisagem a 150dpi sem reduzir muito)
png = tmp / "captura.png"
im = Image.new("RGB", (1240, 1754), "white"); d = ImageDraw.Draw(im)
for y in range(20, 1700, 14): d.text((20, y), "Texto nitido de captura de tela 0123456789", fill="black")
im.save(png, optimize=True)
# Cinza
gray = tmp / "cinza.png"; Image.linear_gradient("L").resize((800, 600)).save(gray)
# JPEG com perfil ICC (sRGB generico) para ver se e preservado
jpg = tmp / "foto.jpg"
prof = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
Image.effect_noise((1240, 1754), 40).convert("RGB").save(jpg, quality=92, icc_profile=prof)

for name, p in [("png_captura", png), ("cinza", gray), ("jpeg_com_icc", jpg)]:
    out = images_to_pdf([p], tmp / f"{name}.pdf", dpi=150, margin_mm=0)
    r = PdfReader(out); page = r.pages[0]
    xo = page["/Resources"]["/XObject"]; img = xo[list(xo)[0]].get_object()
    cs = img["/ColorSpace"]
    print(f"{name:13s} src={p.stat().st_size:>8d}B pdf={out.stat().st_size:>8d}B filtro={img['/Filter']} cs={cs} "
          f"bpc={img['/BitsPerComponent']} mediabox={[round(float(v),2) for v in page.mediabox]} ICCBased={'ICCBased' in str(cs)}")
print("A4 exato em pontos: 595.28 x 841.89")
