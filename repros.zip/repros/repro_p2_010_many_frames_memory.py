"""Memoria de images_to_pdf cresce com o numero de paginas (todas as paginas ficam no PdfWriter ate o final)."""
import _common, sys, tempfile, resource, subprocess, json
from pathlib import Path
if len(sys.argv) == 3:
    from PIL import Image
    from document_tools.pdf_ops import images_to_pdf
    n, tmp = int(sys.argv[1]), Path(sys.argv[2])
    frames = [Image.effect_noise((1500, 2100), 60).convert("RGB") for _ in range(2)]
    tif = tmp / f"m{n}.tif"
    seq = [frames[i % 2] for i in range(n)]
    seq[0].save(tif, save_all=True, append_images=seq[1:], compression="tiff_lzw")
    base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
    images_to_pdf([tif], tmp / f"o{n}.pdf", dpi=300, margin_mm=10)
    print(json.dumps({"paginas": n, "rss_base_MB": base, "rss_pico_MB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024,
                      "pdf_MB": round((tmp / f"o{n}.pdf").stat().st_size / 1e6, 1)}))
else:
    tmp = tempfile.mkdtemp()
    for n in (4, 16, 48):
        print(subprocess.run([sys.executable, __file__, str(n), tmp], capture_output=True, text=True).stdout.strip())
