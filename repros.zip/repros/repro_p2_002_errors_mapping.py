"""Mapeamento de errors.friendly_error_message para excecoes reais."""
import _common, tempfile, zlib
from pathlib import Path
from PIL import Image
import pypdf, pypdf.errors as pe
from document_tools.errors import friendly_error_message as f

tmp = Path(tempfile.mkdtemp())
def show(label, exc):
    print(f"{label:38s} -> {f(exc)!r}")

# Truncada
png = tmp / "t.png"; Image.effect_noise((300, 300), 80).convert("RGB").save(png)
raw = png.read_bytes(); (tmp / "trunc.png").write_bytes(raw[: len(raw) // 2])
try:
    with Image.open(tmp / "trunc.png") as im: im.load()
except Exception as e:
    print("truncada:", type(e).__module__, type(e).__name__, "|", e); show("PNG truncado", e)
# Pillow ValueError cru
try:
    Image.new("RGBA", (4, 4)).save(tmp / "x.jpg", format="JPEG")
except Exception as e:
    print("save RGBA->JPEG:", type(e).__name__, "|", e); show("Pillow ValueError", e)
show("MemoryError", MemoryError())
show("OSError ENOSPC", OSError(28, "No space left on device"))
show("UnicodeEncodeError (ReportLab)", "—".encode("latin-1", "strict") if False else UnicodeEncodeError("latin-1", "—", 0, 1, "ordinal not in range(256)"))
show("ValueError arbitrario", ValueError("invalid literal for int() with base 10: 'x'"))
show("pypdf DependencyError", pe.DependencyError("cryptography>=3.1 is required for AES algorithm"))
show("FileNotFoundError c/ msg acionavel", FileNotFoundError("Arquivo não encontrado: /tmp/b.pdf"))
show("IsADirectoryError", IsADirectoryError(21, "Is a directory"))
print([n for n in dir(pe) if n[0].isupper()])
